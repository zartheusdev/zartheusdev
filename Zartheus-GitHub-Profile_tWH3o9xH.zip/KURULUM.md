# GitHub profil kurulumu

Bu paket GitHub profiline eklenecek README dosyasi ve ona ait SVG gorseli icerir.

1. GitHub hesabinda **zartheusdev** adinda **public** bir repository olustur. (Zaten varsa onu kullan.)
2. Paketteki `README.md` dosyasini repository'nin kokune koy.
3. `assets/zartheus-desktop.svg` dosyasini ayni klasor yapisiyla ekle.
4. Degisiklikleri commit et. Profilinde README otomatik gorunur.

`preview.png` sadece onizleme icindir; yuklemen gerekmez.

Not: README'deki Heus Client ve Foresight, herkese acik GitHub deposu varmis gibi gosterilmiyor; gelistirme projeleri olarak listeleniyor. Tek dogrulanmis repo Totem Warning'dir.
